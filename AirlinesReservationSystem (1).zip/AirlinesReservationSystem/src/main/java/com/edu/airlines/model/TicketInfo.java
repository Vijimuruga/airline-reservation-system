package com.edu.airlines.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotBlank;

@Entity
@SequenceGenerator(name="ticketseq", initialValue = 100000)
public class TicketInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ticketseq")
	private Integer ticketno;
	
    private Float cost;
    
    @NotBlank(message="reservationclass should not be blank")
    private String reservationclass;
    @NotBlank(message="reservationstatus should not be blank")
    private String reservationstatus;
    
	@OneToOne 
	@JoinColumn(name="passenger_id",referencedColumnName = "passengerid")
	private Passenger passenger;
    
    @OneToOne 
	@JoinColumn(name="flight_no",referencedColumnName = "flightno")
	private Flight flight;
    
   public TicketInfo() {
		super();
	}

    public Integer getTicketno() {
		return ticketno;
	}

	public void setTicketno(Integer ticketno) {
		this.ticketno = ticketno;
	}

	public Float getCost() {
		return cost;
	}

	public void setCost(Float cost) {
		this.cost = cost;
	}

	public String getReservationclass() {
		return reservationclass;
	}

	public void setReservationclass(String reservationclass) {
		this.reservationclass = reservationclass;
	}

	public String getReservationstatus() {
		return reservationstatus;
	}

	public void setReservationstatus(String reservationstatus) {
		this.reservationstatus = reservationstatus;
	}

	public Passenger getPassenger() {
		return passenger;
	}


	public void setPassenger(Passenger passenger) {
		this.passenger = passenger;
	}


	public Flight getFlight() {
		return flight;
	}


	public void setFlight(Flight flight) {
		this.flight = flight;
	}


	public void ticketpassenger(Passenger passenger2) {
		this.passenger=passenger2;
	}

	public void ticketflight(Flight flight2) {
		this.flight=flight2;
	}
        
}