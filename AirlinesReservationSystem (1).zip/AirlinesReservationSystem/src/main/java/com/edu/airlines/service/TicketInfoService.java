package com.edu.airlines.service;

import java.util.List;

import javax.validation.Valid;

import com.edu.airlines.model.TicketInfo;

public interface TicketInfoService {

	List<TicketInfo> getTicketDetails();

	TicketInfo bookTicket(@Valid TicketInfo ticketInfo);

	void deleteTicketDetails(Integer ticketno);

	TicketInfo updatePassengerToTicketInfo(Integer ticketno, Integer passengerid);

	TicketInfo updateFlightToTicketInfo(Integer ticketno, Integer flightno);

	TicketInfo updateTicketDetails(Integer ticketno, TicketInfo ticketInfo);

	List<TicketInfo> getTicketDetailsByCost(Float cost);

	List<TicketInfo> getTicketDetailsByReservationClass(String reservationclass);

	List<TicketInfo> getTicketDetailsByReservationStatus(String reservationstatus);

	TicketInfo getTicketByTicketno(Integer ticketno);

}
