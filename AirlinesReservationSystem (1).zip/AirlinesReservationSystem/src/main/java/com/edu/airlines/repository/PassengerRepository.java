package com.edu.airlines.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edu.airlines.model.Passenger;

@Repository
public interface PassengerRepository extends JpaRepository<Passenger, Integer> {

	List<Passenger> findByPassengername(String passengername);
	List<Passenger> findByGender(String gender);
	Passenger findByEmail(String email);
	Passenger findByMobileno(String mobileno);
	List<Passenger> findByAddress(String address);
	Optional<Passenger> findByPassengerid(Integer passengerid);

}
